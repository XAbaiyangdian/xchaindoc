package exec

import (
	"reflect"
	"syscall/js"

	"xa.org/xablockchain/wasmer/contractsdk/go/code"
)

var CH = make(chan bool)

func LoadContract(contract code.Contract) {
	contractv := reflect.ValueOf(contract)

	for i := 0; i < contractv.NumMethod(); i++ {
		funcName := contractv.Type().Method(i).Name
		methodv := contractv.Method(i)
		// method := methodv.Interface().(func(args [][]byte) []byte)
		method := methodv.Interface().(func(ctx code.Context, args []string) code.Response)
		js.Global().Set(funcName, js.FuncOf(func(this js.Value, args []js.Value) interface{} {
			// argBytes := [][]byte{}
			argsStr := []string{}
			context := new(Context)

			for i, v := range args {
				if i == 0 {
					context.ID = v.String()
				} else {
					argsStr = append(argsStr, v.String())
				}
			}

			res := method(context, argsStr)
			resByte := res.Byte()

			rv := js.Global().Get("Uint8Array").New(len(resByte))
			js.CopyBytesToJS(rv, resByte)

			return rv
		}))
	}

	js.Global().Set("CodeExit", js.FuncOf(func(this js.Value, args []js.Value) interface{} {
		CH <- true
		return nil
	}))
}
