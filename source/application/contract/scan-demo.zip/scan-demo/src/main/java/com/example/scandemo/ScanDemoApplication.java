package com.example.scandemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ScanDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScanDemoApplication.class, args);
    }

}
