package example;

import org.junit.Test;
import org.xbl.xchain.sdk.SysConfig;
import org.xbl.xchain.sdk.XchainClient;
import org.xbl.xchain.sdk.block.BlockInfo;
import org.xbl.xchain.sdk.crypto.algo.AlgorithmType;
import org.xbl.xchain.sdk.module.member.types.PermissionPolicy;
import org.xbl.xchain.sdk.tx.TxInfo;
import org.xbl.xchain.sdk.types.*;

import java.io.File;

public class TestWasm {

    /*
    示例合约evidence.wasm是一个存证合约模版 支持对key-value的增删查改 合约源码见xchain文档
    增
    Create { key: String, value: String }
    删
    Delete { key: String }
    改
    Update { key: String, value: String }
    查
    Find { key: String }
     */
    // 部署合约
    @Test
    public void testInstantiateContract() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        String contractName = "evidence";
        String language = "rust";
        File contractFile = new File("src/test/java/wasm/evidence.wasm");
        String executePerm = "";
        String label = "";
        Account acc = Account.buildAccount(new KeyInfo(Config.mne, AlgorithmType.SM2));
        TxResponse txResponse = xchainClient.instantiateContract(acc, contractName, language, contractFile, "{}", PermissionPolicy.POLICY_DROP, executePerm, label);
        assert txResponse.isSuccess();
    }

    // 调用合约 增 create调用时有查重 如果key已经存在将报错 要覆盖已存在的key请调用update
    @Test
    public void testExecuteContract() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        Account acc = Account.buildAccount(new KeyInfo(Config.mne, AlgorithmType.SM2));
        String contractName = "evidence";
        String functionName = "create";
        /*
        调用参数 key和value是两个字符串
        value可以根据实际需求写json字符串
        如下所示
         */
        String args = "{\"key\":\"UUID11235\",\"value\":\"65535\"}";
        // json字符串的存储
//        String args = "{\"key\":\"UUID11235\",\"value\":'{\"name\":\"zhang\",\"age\":\"18\"}'}";
        TxResponse txResponse = xchainClient.executeContract(acc, contractName, functionName, args);
        System.out.println(txResponse);
        // txResponse详细结构见xchain文档
        assert txResponse.isSuccess();
    }

    // 改
    @Test
    public void testUpdate() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        Account acc = Account.buildAccount(new KeyInfo(Config.mne, AlgorithmType.SM2));
        String contractName = "evidence";
        String functionName = "update";
        String args = "{\"key\":\"UUID11235\",\"value\":\"65536\"}";
        TxResponse txResponse = xchainClient.executeContract(acc, contractName, functionName, args);
        assert txResponse.isSuccess();
    }

    // 删
    @Test
    public void testDelete() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        Account acc = Account.buildAccount(new KeyInfo(Config.mne, AlgorithmType.SM2));
        String contractName = "evidence";
        String functionName = "delete";
        String args = "{\"key\":\"UUID11235\"}";
        TxResponse txResponse = xchainClient.executeContract(acc, contractName, functionName, args);
        assert txResponse.isSuccess();
    }

    // 查
    @Test
    public void testQueryContract() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        String contractName = "evidence";
        String functionName = "find";
        String args = "{\"key\":\"UUID11235\"}";
        String queryResult = xchainClient.queryContract(contractName, functionName, args);
        System.out.println(queryResult);
    }

    // 查询交易TxHash TxHash在调用合约时返回的txResponse中的hash给出
    @Test
    public void testQueryTxHash() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        String txHash = "6D726651B86BF784B54611388B88A1A5726405F172B696B8A23CB0D3D380AF77";
        TxInfo txInfo = xchainClient.queryTx(txHash);
        System.out.println(txInfo);
    }

    // 查询区块 交易所在区块高度在调用合约时返回的txResponse中的height给出
    @Test
    public void testQueryBlockByHeight() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        BlockInfo blockInfo = xchainClient.queryBlock("1069");
        System.out.println(blockInfo);
        System.out.println(blockInfo.getBlockTime());
    }
}
