package driver

import (
	"xa.org/xablockchain/wasmer/contractsdk/go/code"
	"xa.org/xablockchain/wasmer/contractsdk/go/exec"
)

func Serve(contract code.Contract) {
	exec.LoadContract(contract)
	<-exec.CH
}
