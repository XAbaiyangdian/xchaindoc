use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use cosmwasm_std::Storage;
use cosmwasm_storage::{ bucket, bucket_read, Bucket, ReadonlyBucket };

pub const KEY: &[u8] = b"trace";

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, JsonSchema)]
pub struct Trace {
    pub id: String,
    pub records: Vec<Record>,
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, JsonSchema)]
pub struct Record {
    pub id: String,
    // 品类：蔬菜、畜禽、水产、花卉园艺、食用菌
    pub category: String,
    // 环节：生产、加工、物流、销售、服务
    pub segment: String,
    pub timestamp: String,
    pub location: String,
    pub responsible_person: String,
}

pub fn trace_store(storage: &mut dyn Storage) -> Bucket<Trace> {
    bucket(storage, KEY)
}

pub fn trace_store_read(storage: &dyn Storage) -> ReadonlyBucket<Trace> {
    bucket_read(storage, KEY)
}
