package org.example;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello!\n这是xchain-java-sdk的一个示例.\n合约部署、调用、查询，交易和区块查询示例见src/test/java/example/TestWasm.\n区块链相关配置项见src/test/java/example/Config.\nsrc/test/java/wasm中的evidence.wasm是示例的存证合约模版.");
    }
}