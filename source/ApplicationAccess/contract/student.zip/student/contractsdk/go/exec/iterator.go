package exec

import (
	"encoding/json"

	"xa.org/xablockchain/wasmer/bridge"
	"xa.org/xablockchain/wasmer/contractsdk/go/code"
)

const MAX_ITERATOR = 100

type kvIterator struct {
	buf          []bridge.IteratorItem // current buffer of the kv items
	curBuf       bridge.IteratorItem   // pointer of current position
	curIdx       int                   // next index
	c            *Context              // where we can get the kv items
	end          bool
	err          error
	start, limit []byte
}

// newkvIterator return a code.Iterator
func newKvIterator(c *Context, start, limit []byte) code.Iterator {
	return &kvIterator{
		start: start,
		limit: limit,
		c:     c,
	}
}

// 批量加载
func (ki *kvIterator) load() {
	//clean the buf at beginning
	ki.buf = ki.buf[0:0]
	req := bridge.IteratorParam{
		Start: ki.start,
		Limit: ki.limit,
		Cap:   MAX_ITERATOR,
	}

	reqByte, _ := json.Marshal(req)
	obj := invoke("NewIterator", []byte(ki.c.ID), reqByte)
	resBuf := js2bytes(obj)

	var resp = &bridge.IteratorResponse{}
	err := json.Unmarshal(resBuf, resp)
	if err != nil {
		ki.err = err
		return
	} else if resp.Err != nil {
		ki.err = resp.Err
		if resp.Err.Error() == gasMsg {
			ki.c.Logln(gasMsg)
			panic(gasMsg)
		}
		return
	}

	if len(resp.Items) == 0 {
		ki.end = true
		return
	}
	lastKey := resp.Items[len(resp.Items)-1].Key
	newStartKey := make([]byte, len(lastKey)+1)
	copy(newStartKey, lastKey)
	newStartKey[len(lastKey)] = 1

	ki.curIdx = 0
	ki.buf = resp.Items
	ki.start = newStartKey
}

func (ki *kvIterator) Key() []byte {
	return ki.curBuf.Key
}

func (ki *kvIterator) Value() []byte {
	return ki.curBuf.Value
}

func (ki *kvIterator) Next() bool {
	if ki.end || ki.err != nil {
		return false
	}
	//永远保证有数据
	if ki.curIdx >= len(ki.buf) {
		ki.load()
		if ki.end || ki.err != nil {
			return false
		}
	}

	ki.curBuf = ki.buf[ki.curIdx]
	ki.curIdx++
	return true
}

func (ki *kvIterator) Error() error {
	return ki.err
}

func (ki *kvIterator) Close() {}
