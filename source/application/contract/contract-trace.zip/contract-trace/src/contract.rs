use cosmwasm_std::{
    entry_point, to_binary, Binary, Deps, DepsMut, Env, MessageInfo,
    QueryResponse, Response, StdResult,
};

use crate::msg::{InstantiateMsg, MigrateMsg, ExecuteMsg, QueryMsg};
use crate::state::{trace_store, trace_store_read, Record, Trace};

// A no-op, just empty data
#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: InstantiateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::Create { record } =>
            create(deps, record),
    }
}

#[entry_point]
pub fn migrate(
    _deps: DepsMut,
    _env: Env,
    _msg: MigrateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn query(
    deps: Deps,
    _env: Env,
    msg: QueryMsg,
) -> StdResult<QueryResponse> {
    match msg {
        QueryMsg::Find { key } =>
            query_key(deps, key),
    }
}
pub fn create(
    deps: DepsMut,
    record: Record,
) -> StdResult<Response> {
    let key = record.id.to_string();
    let existed_value = trace_store_read(deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_none() {
        let mut trace = Trace {
            id: key.to_string(),
            records: vec![],
        };
        trace.records.push(record.clone());
        trace_store(deps.storage).save(key.as_bytes(), &trace)?;
    } else {
        let mut trace = existed_value.unwrap();
        trace.records.push(record.clone());
        trace_store(deps.storage).save(key.as_bytes(), &trace)?;
    }
    Ok(Response::default())
}

fn query_key(
    deps: Deps,
    key: String,
) -> StdResult<Binary> {
    let value = trace_store_read(deps.storage).may_load(key.as_bytes())?;
    to_binary(&value)
}
