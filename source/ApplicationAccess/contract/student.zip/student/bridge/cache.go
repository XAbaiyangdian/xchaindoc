package bridge

import (
	"strconv"
)

/*
	Context Interface
*/

type Cache interface {
	Get(key []byte) ([]byte, error)
	Has(key []byte) (bool, error)
	Set(key, value []byte) error
	Delete(key []byte) error
	NewIterator(params IteratorParam) ([]IteratorItem, error)
	JsonIterator(params JsonIteratorParam) ([]IteratorItem, error)
	SetEvent(key []byte) error
	GetBlockHash() string
	GetBlockHeight() int64
	GetTxHash() string
	GetUser() string
	GetContractAddr() string

	SendCustomMsg(req []byte) ([]byte, error) // 该接口设计为用于区块链节点特殊数据的查询/获取，便于灵活扩展功能
	// SetOutput

	GasLimit() int64
}

type IteratorItem struct {
	Key   []byte `json:"key"`
	Value []byte `json:"value"`
}

type IteratorParam struct {
	Start []byte `json:"start"`
	Limit []byte `json:"limit"`
	Cap   int32  `json:"cap"`
}

type JsonIteratorParam struct {
	Value    string   `json:"value"`
	ValueEnd string   `json:"valueEnd"`
	Limit    int32    `json:"limit"`
	Opt      int32    `json:"opt"`
	Paths    []string `json:"paths"`
	Offset   int32    `json:"offset"`
}

type IteratorResponse struct {
	Items []IteratorItem `json:"items"`
	Err   error          `json:"error"`
}

/*
	Usage:

	var itr Iterator = ...
	defer itr.Close()

	for ; itr.Valid(); itr.Next() {
		k, v := itr.Key(); itr.Value()
		...
	}
*/
// type Iterator interface {
// 	Next()
// 	Valid() bool
// 	Value() []byte
// 	Key() []byte
// 	Close()
// }

type Iterator struct {
	index int
	// ID int
	// TX string
	// 嵌入相应的Iteraror
}

func (t Iterator) Next() {
	t.index++
}
func (t Iterator) Valid() bool {
	return t.index < 5
}
func (t Iterator) Key() []byte {
	num := strconv.Itoa(t.index)
	return []byte("key" + num)
}
func (t Iterator) Value() []byte {
	num := strconv.Itoa(t.index)
	return []byte("value" + num)
}
func (t Iterator) Close() {}
