use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use cosmwasm_std::{CanonicalAddr, Storage};
use cosmwasm_storage::{
    bucket, bucket_read, singleton, singleton_read, Bucket, ReadonlyBucket, ReadonlySingleton,
    Singleton,
};


pub static KEY: &[u8] = b"crud";

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, JsonSchema)]
pub struct State {
    //pub owner: CanonicalAddr,
}

pub fn store<S: Storage>(storage: &mut S) -> Bucket<S, String> {
    bucket(KEY, storage)
}

pub fn store_read<S: Storage>(storage: &S) -> ReadonlyBucket<S, String> {
    bucket_read(KEY, storage)
}

