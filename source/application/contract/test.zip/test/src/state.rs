use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use cosmwasm_std::{Addr, Decimal, Storage, Uint128};
use cosmwasm_storage::{
    bucket, bucket_read, singleton, singleton_read, Bucket, ReadonlyBucket, ReadonlySingleton, 
    Singleton,
};

pub const ITEM_KEY: &[u8] = b"item";

pub fn item_store(storage: &mut dyn Storage) -> Bucket<Item> {
    bucket(storage, ITEM_KEY)
}

pub fn item_store_read(storage: &dyn Storage) -> ReadonlyBucket<Item> {
    bucket_read(storage, ITEM_KEY)
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, JsonSchema)]
pub struct Item {
    pub key: String,
    pub value: String,
}