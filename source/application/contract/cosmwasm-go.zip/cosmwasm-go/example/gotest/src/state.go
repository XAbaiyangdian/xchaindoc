//go:generate ../../../bin/tinyjson -all -snake_case state.go
package src

import (
	"errors"
	"github.com/cosmwasm/cosmwasm-go/std"
)

type Item struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

func LoadItem(storage std.Storage, key string) (*Item, error) {
	data := storage.Get([]byte(key))
	if data == nil {
		return nil, errors.New("item not found")
	}

	var item Item
	err := item.UnmarshalJSON(data)
	if err != nil {
		return nil, err
	}
	return &item, nil
}

func SaveItem(storage std.Storage, item *Item) error {
	bz, err := item.MarshalJSON()
	if err != nil {
		return err
	}

	storage.Set([]byte(item.Key), bz)

	return nil
}
