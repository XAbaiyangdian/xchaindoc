package com.example.scandemo;

import lombok.Data;

@Data
public class ContractEventDTO {
    private String contractName;

    private String key;

    private String value;

    private String txHash;

    public ContractEventDTO(String contractName, String key, String value, String txHash) {
        this.contractName = contractName;
        this.key = key;
        this.value = value;
        this.txHash = txHash;
    }
}
