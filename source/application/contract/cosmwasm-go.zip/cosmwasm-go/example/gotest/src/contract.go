package src

import (
	"github.com/cosmwasm/cosmwasm-go/std"
	"github.com/cosmwasm/cosmwasm-go/std/types"
)

func Instantiate(_ *std.Deps, _ types.Env, _ types.MessageInfo, _ []byte) (*types.Response, error) {
	return &types.Response{}, nil
}

func Migrate(deps *std.Deps, _ types.Env, _ []byte) (*types.Response, error) {
	return &types.Response{}, nil
}

func Execute(deps *std.Deps, env types.Env, info types.MessageInfo, data []byte) (*types.Response, error) {
	msg := ExecuteMsg{}
	err := msg.UnmarshalJSON(data)
	if err != nil {
		return nil, err
	}

	switch {
	case msg.Create != nil:
		return executeCreate(deps, env, info, msg.Create)
	default:
		return nil, types.GenericError("Unknown HandleMsg")
	}
}

func executeCreate(deps *std.Deps, _ types.Env, _ types.MessageInfo, create *Create) (*types.Response, error) {
	//exist, _ := LoadItem(deps.Storage, create.Item.Key)
	//if exist != nil {
	//	return nil, errors.New("key exists")
	//}
	err := SaveItem(deps.Storage, create.Item)
	if err != nil {
		return nil, err
	}
	//itemJson, err := create.Item.MarshalJSON()
	//if err != nil {
	//	return nil, errors.New("MarshalJSON error")
	//}
	//res := &types.Response{
	//	Attributes: []types.EventAttribute{
	//		{"create", string(itemJson)},
	//	},
	//}
	//return res, nil
	return &types.Response{}, nil
}

func Query(deps *std.Deps, _ types.Env, data []byte) ([]byte, error) {
	msg := new(QueryMsg)
	err := msg.UnmarshalJSON(data)
	if err != nil {
		return nil, err
	}

	var res std.JSONType
	switch {
	case msg.Find != nil:
		res, err = query(deps, msg.Find)
	default:
		err = types.GenericError("Unknown QueryMsg")
	}
	if err != nil {
		return nil, err
	}

	bz, err := res.MarshalJSON()
	if err != nil {
		return nil, err
	}
	return bz, nil
}

func query(deps *std.Deps, msg *Find) (*Item, error) {
	value, err := LoadItem(deps.Storage, msg.Key)
	if err != nil {
		return nil, err
	}
	return value, nil
}
