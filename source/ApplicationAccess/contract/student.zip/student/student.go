package main

import (
	"encoding/json"
	"xa.org/xablockchain/wasmer/contractsdk/go/code"
	"xa.org/xablockchain/wasmer/contractsdk/go/driver"
)

type Chaincode struct{}

type Student struct {
	Id    string `json:"id"`
	Name  string `json:"name"`
	Age   int    `json:"age"`
	Score int	 `json:"score"`
}

func (c *Chaincode) Initialize(ctx code.Context, args []string) code.Response {
	return code.OK([]byte("Initialize finish"))
}

func (c *Chaincode) AddScore(ctx code.Context, args []string) code.Response {
	ctx.Logln(args)
	bytes, err := ctx.GetObject([]byte(args[0]))
	if err != nil {
		return code.Error(err)
	}
	var stu = &Student{}
	err1 := json.Unmarshal(bytes, stu)
	if err1 != nil {
		return code.Error(err1)
	}
	stu.Score += 10
	stuJson, err2 := json.Marshal(stu)
	if err2 != nil {
		return code.Error(err2)
	}
	err3 := ctx.PutObject([]byte(args[0]), stuJson)
	if err3 != nil {
		ctx.Logln("Put Error ", err3.Error())
		return code.Error(err3)
	}
	return code.OK([]byte("AddScore Success"))
}

func (c *Chaincode) GetStudent(ctx code.Context, args []string) code.Response {
	ctx.Logln(args)
	bytes, err := ctx.GetObject([]byte(args[0]))
	if err != nil {
		return code.Error(err)
	}

	return code.OK(bytes)
}

func (c *Chaincode) PutStudent(ctx code.Context, args []string) code.Response {
	ctx.Logln(args)
	var stu = &Student{}
	err := json.Unmarshal([]byte(args[0]), stu)
	if err != nil {
		return code.Error(err)
	}
	err1 := ctx.PutObject([]byte(stu.Id), []byte(args[0]))
	if err1 != nil {
		ctx.Logln("Put Error ", err1.Error())
		return code.Error(err1)
	}

	return code.OK([]byte("Put Success"))
}

func (c *Chaincode) DeleteStudent(ctx code.Context, args []string) code.Response {
	ctx.Logln(args)
	err := ctx.DeleteObject([]byte(args[0]))
	if err != nil {
		return code.Error(err)
	}

	return code.OK([]byte("Delete Success"))
}

func main() {
	driver.Serve(new(Chaincode))
}
