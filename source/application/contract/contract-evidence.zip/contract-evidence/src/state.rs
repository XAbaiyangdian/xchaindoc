use cosmwasm_std::Storage;
use cosmwasm_storage::{ bucket, bucket_read, Bucket, ReadonlyBucket };

pub const KEY: &[u8] = b"crud";

pub fn store(storage: &mut dyn Storage) -> Bucket<String> {
    bucket(storage, KEY)
}

pub fn store_read(storage: &dyn Storage) -> ReadonlyBucket<String> {
    bucket_read(storage, KEY)
}
