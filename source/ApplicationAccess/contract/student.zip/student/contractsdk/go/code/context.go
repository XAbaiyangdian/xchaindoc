package code

type Context interface {
	PutObject(key []byte, value []byte) error
	GetObject(key []byte) ([]byte, error)
	DeleteObject(key []byte) error
	NewIterator(start, limit []byte) Iterator
	CrossCall(contractName, method string, args []string) ([]byte, error)
	JsonIterator(paths []string, operator JsonOptType, value string, valueEnd string) Iterator
	SetEvent(map[string]string) ([]byte, error)
	GetBlockHash() string
	GetBlockHeight() int64
	GetTxHash() string
	GetUser() string
	GetContractAddr() string

	SetOutput(data []byte)
	SendCustomMsg(data []byte) ([]byte, error)

	Logln(args ...interface{})
}

type JsonOptType int

const (
	Opt_More JsonOptType = iota
	Opt_Less
	Opt_Equal
	Opt_MoreOrEq
	Opt_LessOrEq
	Opt_Between
)

type Iterator interface {
	Key() []byte
	Value() []byte
	Next() bool
	Error() error
	// Iterator 必须在使用完毕后关闭
	Close()
}

// 前缀查询
func PrefixRange(prefix []byte) ([]byte, []byte) {
	var limit []byte
	for i := len(prefix) - 1; i >= 0; i-- {
		c := prefix[i]
		if c < 0xff {
			limit = make([]byte, i+1)
			copy(limit, prefix)
			limit[i] = c + 1
			break
		}
	}
	return prefix, limit
}
