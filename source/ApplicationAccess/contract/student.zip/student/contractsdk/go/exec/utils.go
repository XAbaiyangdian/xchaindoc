package exec

import (
	"encoding/json"
	"syscall/js"
)

func js2bytes(value interface{}) []byte {
	v := value.(js.Value)
	buf := make([]byte, v.Length(), v.Length())
	js.CopyBytesToGo(buf, v)

	return buf
}

func bytes2js(b []byte) js.Value {
	v := js.Global().Get("Uint8Array").New(len(b))
	js.CopyBytesToJS(v, b)

	return v
}

func invoke(name string, args ...[]byte) interface{} {
	byteArgs, _ := json.Marshal(args)
	jsArgs := bytes2js(byteArgs)
	// log.Println("Invoke CallMethod: " + name)
	return js.Global().Get("CallMethod").Invoke(name, jsArgs)
}
