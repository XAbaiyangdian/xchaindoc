package bridge

import (
	"errors"
)

const (
	FAILURE   = 500
	GASBEYOND = 501
	SUCCESS   = 200

	QUERY  = "query"
	INVOKE = "invoke"
	CROSS  = "cross"
)

var GAS_LIMIT_ERROR = errors.New("Gas exceeds the maximum limit")

type Response struct {
	Result  int      `json:"status"`
	Message string   `json:"message"`
	Body    []byte   `json:"body"`
	Output  [][]byte `json:"-"`

	GasCal
}
