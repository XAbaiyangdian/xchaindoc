#   合约执行接口 这是一个存证合约模版 支持对key-value的增删查改

##  1.增

    Create { key: String, value: String }

    新建有查重，如果key已经存在将报错

##  2.删

    Delete { key: String }

##  3.改

    Update { key: String, value: String }

#   合约查询接口

##  查

    Find { key: String }

    返回查询的key对应的value值
    测试用例查询key为UUID11235，输出为对应value的值65535
