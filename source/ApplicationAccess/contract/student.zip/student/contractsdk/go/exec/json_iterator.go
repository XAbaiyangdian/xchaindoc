package exec

import (
	"encoding/json"

	"xa.org/xablockchain/wasmer/bridge"
	"xa.org/xablockchain/wasmer/contractsdk/go/code"
)

type jsonIterator struct {
	buf          []bridge.IteratorItem // current buffer of the kv items
	curBuf       bridge.IteratorItem   // pointer of current position
	curIdx       int                   // next index
	c            *Context              // where we can get the kv items
	end          bool
	err          error
	start, limit string
	opt          code.JsonOptType
	paths        []string
	offset       int
}

// newkvIterator return a code.Iterator
func newJsonIterator(c *Context, paths []string, opt code.JsonOptType, start, limit string) code.Iterator {
	return &jsonIterator{
		start: start,
		limit: limit,
		c:     c,
		paths: paths,
		opt:   opt,
	}
}

// 批量加载
func (ki *jsonIterator) load() {
	//clean the buf at beginning
	ki.buf = ki.buf[0:0]
	req := bridge.JsonIteratorParam{
		Value:    ki.start,
		ValueEnd: ki.limit,
		Limit:    MAX_ITERATOR,
		Paths:    ki.paths,
		Opt:      int32(ki.opt),
		Offset:   int32(ki.offset),
	}

	reqByte, _ := json.Marshal(req)
	obj := invoke("NewJsonIterator", []byte(ki.c.ID), reqByte)
	resBuf := js2bytes(obj)

	var resp = &bridge.IteratorResponse{}
	err := json.Unmarshal(resBuf, resp)
	if err != nil {
		ki.err = err
		return
	} else if resp.Err != nil {
		ki.err = resp.Err
		if resp.Err.Error() == gasMsg {
			ki.c.Logln(gasMsg)
			panic(gasMsg)
		}
		return
	}

	if len(resp.Items) == 0 {
		ki.end = true
		return
	}

	ki.curIdx = 0
	ki.buf = resp.Items

	// 计算offset
	if len(resp.Items) < MAX_ITERATOR {
		ki.offset += len(resp.Items)
	} else {
		ki.offset += MAX_ITERATOR
	}
}

func (ki *jsonIterator) Key() []byte {
	return ki.curBuf.Key
}

func (ki *jsonIterator) Value() []byte {
	return ki.curBuf.Value
}

func (ki *jsonIterator) Next() bool {
	if ki.end || ki.err != nil {
		return false
	}
	//永远保证有数据
	if ki.curIdx >= len(ki.buf) {
		ki.load()
		if ki.end || ki.err != nil {
			return false
		}
	}

	ki.curBuf = ki.buf[ki.curIdx]
	ki.curIdx++
	return true
}

func (ki *jsonIterator) Error() error {
	return ki.err
}

func (ki *jsonIterator) Close() {}
