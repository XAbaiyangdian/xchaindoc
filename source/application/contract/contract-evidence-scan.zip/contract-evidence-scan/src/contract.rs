use cosmwasm_std::{
    entry_point, to_binary, Binary, Deps, DepsMut, Env, MessageInfo,
    QueryResponse, Response, StdResult, StdError,
};

use crate::msg::{InstantiateMsg, MigrateMsg, ExecuteMsg, QueryMsg};
use crate::state::{store, store_read};

// A no-op, just empty data
#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: InstantiateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::Create { key, value } =>
            create(deps, key, value),
        ExecuteMsg::Update{ key, value }=>
            update(deps, key, value),
        ExecuteMsg::Delete{ key }=>
            delete(deps, key),
    }
}

#[entry_point]
pub fn migrate(
    _deps: DepsMut,
    _env: Env,
    _msg: MigrateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn query(
    deps: Deps,
    _env: Env,
    msg: QueryMsg,
) -> StdResult<QueryResponse> {
    match msg {
        QueryMsg::Find { key } =>
            query_key(deps, key),
    }
}
pub fn create(
    deps: DepsMut,
    key: String,
    value: String,
) -> StdResult<Response> {
    let existed_value = store_read(deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_some() {
        return Err(StdError::generic_err("The key already existed"));
    }
    store(deps.storage).save(key.as_bytes(), &value)?;
    // 触发事件 用于scan-demo扫块和监听
    Ok(Response::default().add_attribute("method", "create").add_attribute("key", &key).add_attribute("value", &value))
}

pub fn update(
    deps: DepsMut,
    key: String,
    value: String,
) -> StdResult<Response> {
    let existed_value = store_read(deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_none() {
        return Err(StdError::generic_err("The key not exists"));
    }
    store(deps.storage).save(key.as_bytes(), &value)?;
    Ok(Response::default())
}

pub fn delete(
    deps: DepsMut,
    key: String,
) -> StdResult<Response> {
    let existed_value = store(deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_none() {
        return Err(StdError::generic_err("The key not exists"));
    }
    store(deps.storage).remove(key.as_bytes());
    Ok(Response::default())
}

fn query_key(
    deps: Deps,
    key: String,
) -> StdResult<Binary> {
    let value = store_read(deps.storage).may_load(key.as_bytes())?;
    to_binary(&value)
}
