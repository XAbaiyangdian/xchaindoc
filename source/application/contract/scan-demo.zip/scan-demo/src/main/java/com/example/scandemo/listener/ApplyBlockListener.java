package com.example.scandemo.listener;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.scandemo.ContractEventDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.xbl.xchain.sdk.SysConfig;
import org.xbl.xchain.sdk.XchainClient;
import org.xbl.xchain.sdk.module.wasm.msg.MsgExecuteContract;
import org.xbl.xchain.sdk.tx.StdTx;
import org.xbl.xchain.sdk.tx.TxInfo;
import org.xbl.xchain.sdk.types.Msg;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
public class ApplyBlockListener {

    @Resource
    private ApplyBlockListener applyBlockListener;

    // 从哪个块开始扫
    // java-sdk中执行交易返回的txResponse中查看hash
    // testQueryTxHash查询该hash可以查到此交易所在块高
    private static Long nextScanHeight = 168299L;

    @Scheduled(cron = "0/5 * * * * ? ")
    public void scanBlock() {
        Long currentBlockChainHeight = null;
        try {
            currentBlockChainHeight = getCurrentBlockChainHeight();
        } catch (Exception e) {
            log.error("getCurrentBlockChainHeight异常:{}",e.getMessage(),e);
        }
        if (currentBlockChainHeight == null || currentBlockChainHeight == 0L) {
            return;
        }
        Long previousBlockChainHeight = currentBlockChainHeight - 1;
        if (nextScanHeight <= previousBlockChainHeight) {
            for (long i = nextScanHeight; i <= previousBlockChainHeight; i++){
                applyBlockListener.scanByHeight(i);
            }
        }
        nextScanHeight = previousBlockChainHeight + 1;
    }

    public void scanByHeight(Long scanBlockHeight) {
        log.info(scanBlockHeight.toString());
        List<ContractEventDTO> contractEventDTOS = null;
        try {
            contractEventDTOS = geTxsEventsByHeight(scanBlockHeight, Arrays.asList(new String[]{Config.contractName}));
        } catch (Exception e) {
            log.error("geTxsEventsByHeight异常,高度："+scanBlockHeight);
            log.error("geTxsEventsByHeight异常:{}",e.getMessage(),e);
        }
        for (ContractEventDTO contractEventDto : contractEventDTOS) {
            log.info(JSONObject.toJSONString(contractEventDto));
        }
    }

    public Long getCurrentBlockChainHeight() throws Exception {
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        return xchainClient.getLatestBlock().getBlockHeight();
    }

    public List<ContractEventDTO> geTxsEventsByHeight(Long height, List<String> contractNames) throws Exception {
        List<ContractEventDTO> contractEventDTOS = new ArrayList<>();
        SysConfig sysConfig = new SysConfig(Config.url, Config.chainId, "2");
        XchainClient xchainClient = new XchainClient(sysConfig);
        List<TxInfo> txInfos = xchainClient.queryTxs(height);
        for (TxInfo txInfo : txInfos) {
            // 过滤非相关合约名称
            StdTx tx = txInfo.getTx();
            if (tx == null) {
                continue;
            }
            Msg[] msgs = tx.getMsg();
            if (!"wasm/MsgExecuteContract".equals(msgs[0].type())) {
                continue;
            }
            MsgExecuteContract msg = (MsgExecuteContract) msgs[0];
            String contractName = msg.getContractName();
            if (!contractNames.contains(Config.contractName)){
                continue;
            }
            if (txInfo.getLogs() == null) {
                continue;
            }
            for (TxInfo.TxLog txLog : txInfo.getLogs()) {
                for (TxInfo.Event event : txLog.getEvents()) {
                    //过滤event类型 wasm 为合约内部抛出
                    if (!"wasm".equals(event.getType())) {
                        continue;
                    }
                    for (TxInfo.Attribute attribute : event.getAttributes()) {
                        if ("contract_address".equals(attribute.getKey())) {
                            continue;
                        }
                        contractEventDTOS.add(new ContractEventDTO(contractName, attribute.getKey(), attribute.getValue(), txInfo.getTxhash()));
                    }
                }
            }
        }
        return contractEventDTOS;
    }
}
