# Crypto Verify Contract

This is a simple contract to demonstrate cryptographic signature verification
from contracts.

ECDSA P256 parameters are currently supported.

## Formats

Input formats are serialized byte slices for Message, Signature, and Public Key.

### P256:

- Message: A serialized message. It will be hashed by the contract using
  SHA-256, and the hashed value will be fed to the verification function.
- Signature: Serialized signature, in "compact" Fabric format (64 bytes).
- Public Key: uncompressed (65 bytes) serialized public
  key, in SEC format.

Output is a boolean value indicating if verification succeeded or not.

## Remarks

In case of an error (wrong or unsupported inputs), the current implementation
returns an error, which can be easily handled by the contract, or returned to
the client.
