package src

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/cosmwasm/cosmwasm-go/std"
	"github.com/cosmwasm/cosmwasm-go/std/mock"
	"github.com/cosmwasm/cosmwasm-go/std/types"
)

func mustEncode(t *testing.T, msg interface{}) []byte {
	bz, err := json.Marshal(msg)
	require.NoError(t, err)
	return bz
}

const FUNDER = "creator"

// this can be used for a quick setup if you don't have nay other requirements
func defaultInit(t *testing.T, funds []types.Coin) *std.Deps {
	deps := mock.Deps(funds)
	env := mock.Env()
	info := mock.Info(FUNDER, funds)
	initMsg := InstantiateMsg{}
	res, err := Instantiate(deps, env, info, mustEncode(t, initMsg))
	require.NoError(t, err)
	require.NotNil(t, res)
	return deps
}

func TestCreate(t *testing.T) {
	deps := defaultInit(t, nil)
	env := mock.Env()
	info := mock.Info(FUNDER, nil)
	handleMsg := []byte(`{"create":{"item":{"key":"1","value":"a"}}}`)
	_, _ = Execute(deps, env, info, handleMsg)
}

func TestQuery(t *testing.T) {
	deps := defaultInit(t, nil)
	env := mock.Env()
	info := mock.Info(FUNDER, nil)
	handleMsg := []byte(`{"create":{"item":{"key":"1","value":"a"}}}`)
	_, _ = Execute(deps, env, info, handleMsg)
	queryMsg := []byte(`{"find":{"key":"1"}}`)
	data, err := Query(deps, env, queryMsg)
	require.NoError(t, err)
	println(string(data))
}
