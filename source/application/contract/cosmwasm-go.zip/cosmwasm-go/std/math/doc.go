// Package math contains some human-readable mathematical primitives.
package math
