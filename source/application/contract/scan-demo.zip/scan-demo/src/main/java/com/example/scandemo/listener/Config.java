package com.example.scandemo.listener;

// 配置信息
public class Config {
    // 区块链节点url
    public static String url = "http://ip:port";
    // chainID
    public static String chainId = "XCHAIN21bfe20e42d646c7a4cf663253adb2ee";
    // 链上账户助记词
    public static String mne = "徙 需 校 慰 末 辞 腊 瞧 逻 冶 铅 讲 觉 残 框 又 频 招 朝 表 离 链 电 闲";
    public static String contractName = "evidence_scan";
}
