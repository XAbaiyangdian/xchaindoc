//go:generate ../../../bin/tinyjson -all -snake_case msg.go
package src

type InstantiateMsg struct{}

type ExecuteMsg struct {
	Create *Create `json:"create"`
}

type Create struct {
	Item *Item `json:"item"`
}

type QueryMsg struct {
	Find *Find `json:"find"`
}

type Find struct {
	Key string `json:"key"`
}

type MigrateMsg struct{}

type QueryResponse struct {
	Item *Item `json:"item"`
}

type CrossMsg struct {
	Create *CrossParam `json:"create"`
}

type CrossParam struct {
	Item *Item `json:"item"`
}
