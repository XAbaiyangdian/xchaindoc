#   合约执行接口

##  增加条目

    create { record: Record }

    ### 示例 
    
    调用方法 create

    调用参数

    {"record":{"responsible_person":"dazhi","segment":"生产","location":"雄安某养猪场","id":"111111","category":"畜禽","timestamp":"2023-1-1"}}

    {"record":{"responsible_person":"huohuo","segment":"加工","location":"雄安某屠宰场","id":"111111","category":"畜禽","timestamp":"2023-5-1"}}

    {"record":{"responsible_person":"boge","segment":"物流","location":"雄安到北京某超市","id":"111111","category":"畜禽","timestamp":"2023-5-2"}}

    {"record":{"responsible_person":"xiaoliang","segment":"销售","location":"北京某超市","id":"111111","category":"畜禽","timestamp":"2023-5-3"}}


#   合约查询接口

##  查

    Find { key: String }

    ### 示例 
    
    调用方法 find

    调用参数

    {"key":"111111"}

    查询结果

    {"records":[{"responsible_person":"dazhi","segment":"生产","location":"雄安某养猪场","id":"111111","category":"畜禽","timestamp":"2023-1-1"},{"responsible_person":"huohuo","segment":"加工","location":"雄安某屠宰场","id":"111111","category":"畜禽","timestamp":"2023-5-1"},{"responsible_person":"boge","segment":"物流","location":"雄安到北京某超市","id":"111111","category":"畜禽","timestamp":"2023-5-2"},{"responsible_person":"xiaoliang","segment":"销售","location":"北京某超市","id":"111111","category":"畜禽","timestamp":"2023-5-3"}],"id":"111111"}
