use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use cosmwasm_std::{
    entry_point, from_slice, to_binary, to_vec, Binary, Deps, DepsMut, Env, MessageInfo, Order,
    QueryResponse, Response, StdResult, Storage, StdError, Attribute,
};

use crate::msg::{InstantiateMsg, MigrateMsg, ExecuteMsg, QueryMsg};
use crate::state::{Item, item_store, item_store_read};

// A no-op, just empty data
#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: InstantiateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::Create { item } => create(deps, item),
    }
}

#[entry_point]
pub fn query(
    deps: Deps,
    _env: Env,
    msg: QueryMsg,
) -> StdResult<QueryResponse> {
    match msg {
        QueryMsg::Find { key } => find(deps, key),
    }
}

#[entry_point]
pub fn migrate(
    _deps: DepsMut,
    _env: Env,
    _msg: MigrateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

fn create(deps: DepsMut, item: Item) -> StdResult<Response> {
    item_store(deps.storage).save(item.key.as_bytes(), &item)?;
    let attribute_value = serde_json_wasm::to_string(&item).unwrap();
    Ok(Response::new()
        .add_attribute("create", attribute_value))
}

fn find(deps: Deps, key: String) -> StdResult<QueryResponse> {
    let item_option = item_store_read(deps.storage).may_load(key.as_bytes())?;
    if item_option.is_none() {
        return Err(StdError::generic_err("key not exist"));
    }
    let item = item_option.unwrap();
    to_binary(&item)
}