use cosmwasm_std::{to_binary, Api, Binary, Env, Extern, HandleResponse, InitResponse, Querier, StdError, StdResult, Storage, MigrateResponse};
use crate::msg::{HandleMsg, InitMsg, QueryMsg, MigrateMsg};
use crate::state::{ store, store_read,};
//合约实例化时调用，初始化合约
pub fn init<S: Storage, A: Api, Q: Querier>(
    deps: &mut Extern<S, A, Q>,
    env: Env,
    msg: InitMsg,
) -> StdResult<InitResponse> {
    Ok(InitResponse::default())
}

pub fn handle<S: Storage, A: Api, Q: Querier>(
    deps: &mut Extern<S, A, Q>,
    env: Env,
    msg: HandleMsg,
) -> StdResult<HandleResponse> {
    match msg {
        HandleMsg::Create {key, value} =>
            create(deps, env, key, value),
        HandleMsg::Update{key, value}=>
            update(deps, env, key, value),
        HandleMsg::Delete{key}=>
            delete(deps, env, key),
    }
}

pub fn migrate<S: Storage, A: Api, Q: Querier>(
    deps: &mut Extern<S, A, Q>,
    env: Env,
    msg: MigrateMsg,
) -> StdResult<MigrateResponse> {
    Ok(MigrateResponse::default())
}

pub fn query<S: Storage, A: Api, Q: Querier>(
    deps: &Extern<S, A, Q>,
    msg: QueryMsg,
) -> StdResult<Binary> {
    match msg {
        QueryMsg::Find { key } =>
            query_key(deps, key),
    }
}
pub fn create<S: Storage, A: Api, Q: Querier>(
    deps: &mut Extern<S, A, Q>,
    _env: Env,
    key: String,
    value: String,
) -> StdResult<HandleResponse> {
    let existed_value = store(&mut deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_some() {
        return Err(StdError::generic_err("The key already existed"));
    }
    store(&mut deps.storage).save(key.as_bytes(), &value)?;
    Ok(HandleResponse::default())
}

pub fn update<S: Storage, A: Api, Q: Querier>(
    deps: &mut Extern<S, A, Q>,
    _env: Env,
    key: String,
    value: String,
) -> StdResult<HandleResponse> {
    let existed_value = store(&mut deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_none() {
        return Err(StdError::generic_err("The key not exists"));
    }
    store(&mut deps.storage).save(key.as_bytes(), &value)?;
    Ok(HandleResponse::default())
}

pub fn delete<S: Storage, A: Api, Q: Querier>(
    deps: &mut Extern<S, A, Q>,
    _env: Env,
    key: String,
) -> StdResult<HandleResponse> {
    let existed_value = store(&mut deps.storage).may_load(key.as_bytes())?;
    if existed_value.is_none() {
        return Err(StdError::generic_err("The key not exists"));
    }
    store(&mut deps.storage).remove(key.as_bytes());
    Ok(HandleResponse::default())
}

fn query_key<S: Storage, A: Api, Q: Querier>(
    deps: &Extern<S, A, Q>,
    key: String,
) -> StdResult<Binary> {
    let value =  store_read(&deps.storage).may_load(key.as_bytes())? ;
    to_binary(&value)
}


