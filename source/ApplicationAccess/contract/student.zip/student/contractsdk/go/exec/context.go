package exec

import (
	"encoding/json"
	"errors"
	"strconv"

	"xa.org/xablockchain/wasmer/bridge"
	"xa.org/xablockchain/wasmer/contractsdk/go/code"
)

const gasMsg = "Gas exceeds the maximum limit"

type Context struct {
	ID string
}

func (ctx *Context) GetObject(key []byte) ([]byte, error) {
	obj := invoke("GetObject", []byte(ctx.ID), key)
	buf := js2bytes(obj)

	var res = bridge.Response{}
	err := json.Unmarshal(buf, &res)
	if err != nil {
		return nil, errors.New("GetObject Unmarshal Error, Byte: " + string(buf))
	}

	if res.Result == bridge.SUCCESS {
		return res.Body, nil
	} else if res.Result == bridge.GASBEYOND {
		ctx.Logln(gasMsg)
		panic(gasMsg)
	}

	return nil, errors.New(res.Message)
}

func (ctx *Context) PutObject(key []byte, value []byte) error {
	obj := invoke("PutObject", []byte(ctx.ID), key, value)
	buf := js2bytes(obj)

	var res = bridge.Response{}
	err := json.Unmarshal(buf, &res)
	if err != nil {
		return errors.New("GetObject Unmarshal Error, Byte: " + string(buf))
	}

	if res.Result == bridge.SUCCESS {
		return nil
	} else if res.Result == bridge.GASBEYOND {
		ctx.Logln(gasMsg)
		panic(gasMsg)
	}

	return errors.New(res.Message)
}

func (ctx *Context) DeleteObject(key []byte) error {
	obj := invoke("DeleteObject", []byte(ctx.ID), key)
	buf := js2bytes(obj)

	var res = bridge.Response{}
	err := json.Unmarshal(buf, &res)
	if err != nil {
		return errors.New("GetObject Unmarshal Error, Byte: " + string(buf))
	}

	if res.Result == bridge.SUCCESS {
		return nil
	} else if res.Result == bridge.GASBEYOND {
		ctx.Logln(gasMsg)
		panic(gasMsg)
	}

	return errors.New(res.Message)
}

func (ctx *Context) NewIterator(start, limit []byte) code.Iterator {
	return newKvIterator(ctx, start, limit)
}

func (ctx *Context) JsonIterator(paths []string, operator code.JsonOptType, value string, valueEnd string) code.Iterator {
	return newJsonIterator(ctx, paths, operator, value, valueEnd)
}

func (ctx *Context) CrossCall(contractName, method string, args []string) ([]byte, error) {
	crossArgs := [][]byte{[]byte(ctx.ID), []byte(contractName), []byte(method)}
	for _, v := range args {
		crossArgs = append(crossArgs, []byte(v))
	}
	obj := invoke("CrossContract", crossArgs...)
	buf := js2bytes(obj)

	var res = bridge.Response{}
	err := json.Unmarshal(buf, &res)
	if err != nil {
		return nil, errors.New("CrossContract Response Unmarshal Error, Byte: " + string(buf))
	}

	if res.Result == bridge.SUCCESS {
		return res.Body, nil
	} else if res.Result == bridge.GASBEYOND {
		ctx.Logln(gasMsg)
		panic(gasMsg)
	}

	return nil, errors.New(res.Message)
}

func (ctx *Context) SetEvent(param map[string]string) ([]byte, error) {
	key, err := json.Marshal(param)
	if err != nil {
		return nil, errors.New("SetEvent Marshal Error, Byte: " + string(key))
	}
	obj := invoke("SetEvent", []byte(ctx.ID), key)
	buf := js2bytes(obj)

	var res = bridge.Response{}
	err = json.Unmarshal(buf, &res)
	if err != nil {
		return nil, errors.New("SetEvent Unmarshal Error, Byte: " + string(buf))
	}

	if res.Result == bridge.SUCCESS {
		return res.Body, nil
	} else if res.Result == bridge.GASBEYOND {
		ctx.Logln(gasMsg)
		panic(gasMsg)
	}

	return nil, errors.New(res.Message)
}

func (ctx *Context) GetBlockHash() string {
	obj := invoke("GetBlockHash", []byte(ctx.ID))
	buf := js2bytes(obj)

	return string(buf)
}

func (ctx *Context) GetBlockHeight() int64 {
	obj := invoke("GetBlockHeight", []byte(ctx.ID))
	buf := js2bytes(obj)
	v, _ := strconv.ParseInt(string(buf), 10, 64)
	return v
}

func (ctx *Context) GetTxHash() string {
	obj := invoke("GetTxHash", []byte(ctx.ID))
	buf := js2bytes(obj)

	return string(buf)
}

func (ctx *Context) GetUser() string {
	obj := invoke("GetUser", []byte(ctx.ID))
	buf := js2bytes(obj)

	return string(buf)
}

func (ctx *Context) GetContractAddr() string {
	obj := invoke("GetContractAddr", []byte(ctx.ID))
	buf := js2bytes(obj)

	return string(buf)
}

func (ctx *Context) SendCustomMsg(req []byte) ([]byte, error) {
	obj := invoke("SendCustomMsg", []byte(ctx.ID), req)
	buf := js2bytes(obj)

	var res = bridge.Response{}
	err := json.Unmarshal(buf, &res)
	if err != nil {
		return nil, errors.New("SendCustomMsg Unmarshal Error, Byte: " + string(buf))
	}

	if res.Result == bridge.SUCCESS {
		return res.Body, nil
	} else if res.Result == bridge.GASBEYOND {
		ctx.Logln(gasMsg)
		panic(gasMsg)
	}

	return nil, errors.New(res.Message)
}

func (ctx *Context) SetOutput(data []byte) {
	invoke("SetOutput", []byte(ctx.ID), data)
}

func (ctx *Context) Logln(args ...interface{}) {
	// log.Println(args)
	bs, _ := json.Marshal(args)
	// logArgs := [][]byte{}
	// for _, v := range args {
	// 	logArgs = append(logArgs, []byte(ctx.ID), []byte(v))
	// }
	invoke("Logln", []byte(ctx.ID), bs)
}
