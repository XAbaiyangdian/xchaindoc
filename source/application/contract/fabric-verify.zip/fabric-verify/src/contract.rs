use cosmwasm_std::{
    entry_point, Binary, Deps, DepsMut, Env, MessageInfo, Response, QueryResponse, 
    StdError, StdResult,
};

use p256::ecdsa::{signature::Verifier, Signature, VerifyingKey};

use p256::ecdsa::signature::Signature as _;

use std::convert::TryInto;

use crate::msg::{ExecuteMsg, InstantiateMsg, MigrateMsg, QueryMsg, SignedData};

extern crate pem;

use pem::parse;

use x509_parser::parse_x509_certificate;

use x509_parser::prelude::*;

// A no-op, just empty data
#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: InstantiateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn migrate(
    _deps: DepsMut,
    _env: Env,
    _msg: MigrateMsg,
) -> StdResult<Response> {
    Ok(Response::default())
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::FabricVerify {
            signed_datas,
            root_certificates,
        } => verify_fabric_batch(deps, signed_datas, root_certificates),
    }
}

#[entry_point]
pub fn query(
    _deps: Deps,
    _env: Env,
    _msg: QueryMsg,
) -> StdResult<QueryResponse> {
    Ok(Binary::from(vec![1]))
}

pub fn verify_fabric_batch(
    _deps: DepsMut,
    signed_datas: Vec<SignedData>,
    root_certificates: Vec<String>,
) -> StdResult<Response> {
    let mut res: bool = false;
    let mut err: bool = false;
    let mut response = "";

    for root_certificate in root_certificates {
        let mut temp = true;
        for signed_data in &signed_datas {
            match verify_identity(
                signed_data.identity.to_string(),
                root_certificate.to_string(),
            ) {
                Ok(result) => temp = result,
                Err(_) => err = true,
            };
            if temp == false || err == true {
                break;
            }
        }
        if temp == true || err == true {
            res = true;
            break;
        }
    }

    if err == true {
        response = "FormatErr";
        res = false;
    } else if res == false {
        response = "CertificateVerifyFailed";
    }

    if res == true {
        for item in &signed_datas {
            match query_verify_fabric(
                item.data.to_string(),
                item.identity.to_string(),
                item.signature.to_string(),
            ) {
                Ok(result) => {
                    res = result;
                }
                Err(_) => {
                    err = true;
                }
            }
            if res == true || err == true {
                break;
            }
        }
        if err == true {
            response = "FormatErr";
        }
    }
    if res == false && response == "" {
        response = "SignatureVerifyFailed";
    }

    let result = {
        if res == true && err == false {
            "ok"
        } else {
            response
        }
    };
    Ok(Response::new().set_data(Binary::from(result.as_bytes())))
}

pub fn query_verify_fabric(
    data: String,
    identity: String,
    signature: String,
) -> Result<bool, StdError> {
    let data = hex::decode(data);
    if data.is_err() {
        return Err(StdError::generic_err("DecodeErr"));
    }
    let data = data.unwrap();
    let data = data.as_slice();

    let identity = hex::decode(identity);
    if identity.is_err() {
        return Err(StdError::generic_err("DecodeErr"));
    }
    let identity = identity.unwrap();
    let identity = identity.as_slice();

    let public_key = read_public_key(identity)?;
    let public_key = hex::decode(public_key);
    if public_key.is_err() {
        return Err(StdError::generic_err("DecodeErr"));
    }
    let public_key = public_key.unwrap();
    let public_key = public_key.as_slice();

    let verify_key = VerifyingKey::from_sec1_bytes(public_key)
        .map_err(|e| StdError::generic_err(e.to_string()))?;

    let signature = read_signature(signature)?;

    let signature =
        Signature::from_bytes(&signature).map_err(|e| StdError::generic_err(e.to_string()))?;

    let verifies = match verify_key.verify(data, &signature) {
        Ok(()) => true,
        Err(_) => false,
    };
    Ok(verifies)
}

fn read_signature(data: String) -> Result<[u8; 64], StdError> {
    if data.len() == 140 {
        let data = [&data[8..72], &data[76..]].concat();
        let data = hex::decode(data);
        if data.is_err() {
            return Err(StdError::generic_err("DecodeErr"));
        }
        let data = data.unwrap();
        let data = data.as_slice();
        data.try_into()
            .map_err(|_| StdError::generic_err("InvalidP256SignatureFormat"))
    } else if data.len() == 142 {
        let data = [&data[10..74], &data[78..]].concat();
        let data = hex::decode(data);
        if data.is_err() {
            return Err(StdError::generic_err("DecodeErr"));
        }
        let data = data.unwrap();
        let data = data.as_slice();
        data.try_into()
            .map_err(|_| StdError::generic_err("InvalidP256SignatureFormat"))
    } else {
        return Err(StdError::generic_err("InvalidSignatureLength"));
    }
}

fn read_public_key(identity: &[u8]) -> Result<String, StdError> {
    let data = String::from_utf8_lossy(identity);
    let pem = parse(data.as_ref());
    if pem.is_err() {
        return Err(StdError::generic_err("PemParseErr"));
    }
    let pem = pem.unwrap();
    let res = parse_x509_certificate(&pem.contents);
    match res {
        Ok((_rem, x509)) => {
            let public_key: &[u8] = x509.public_key().subject_public_key.data;
            let public_key = hex::encode(public_key);
            Ok(public_key)
        }
        _ => Err(StdError::generic_err("x509ParsingFailed")),
    }
}

fn verify_identity(identity: String, root_certificate: String) -> Result<bool, StdError> {
    let identity = hex::decode(identity);
    if identity.is_err() {
        return Err(StdError::generic_err("DecodeErr"));
    }
    let identity = identity.unwrap();
    let identity = identity.as_slice();
    let data = String::from_utf8_lossy(identity);
    let pem = parse(data.as_ref());
    if pem.is_err() {
        return Err(StdError::generic_err("PemParseErr"));
    }
    let pem = pem.unwrap();
    let res = parse_x509_certificate(&pem.contents);
    if res.is_err() {
        return Err(StdError::generic_err("X509ParseErr"));
    }
    let cert = res.unwrap().1;
    let identity = hex::decode(root_certificate);
    if identity.is_err() {
        return Err(StdError::generic_err("DecodeErr"));
    }
    let identity = identity.unwrap();
    let identity = identity.as_slice();
    let data = String::from_utf8_lossy(identity);
    let pem = parse(data.as_ref());
    if pem.is_err() {
        return Err(StdError::generic_err("PemParseErr"));
    }
    let pem = pem.unwrap();
    let res = parse_x509_certificate(&pem.contents);
    if res.is_err() {
        return Err(StdError::generic_err("X509ParseErr"));
    }
    let issuer = res.unwrap().1;
    let res = check_signature(&cert, &issuer);
    res
}

pub fn check_signature(
    cert: &X509Certificate<'_>,
    issuer: &X509Certificate<'_>,
) -> Result<bool, StdError> {
    let raw = cert.tbs_certificate.as_ref();
    let issuer_public_key = issuer.public_key().subject_public_key.data;
    let verify_key = VerifyingKey::from_sec1_bytes(issuer_public_key)
        .map_err(|e| StdError::generic_err(e.to_string()))?;
    let signature = cert.signature_value.data;
    let signature = hex::encode(signature);
    let signature = read_signature(signature)?;
    let signature =
        Signature::from_bytes(&signature).map_err(|e| StdError::generic_err(e.to_string()))?;
    let verifies = match verify_key.verify(raw, &signature) {
        Ok(()) => true,
        Err(_) => false,
    };
    Ok(verifies)
}
