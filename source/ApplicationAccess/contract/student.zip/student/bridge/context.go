package bridge

type Context struct {
	ID int64
	// 合约名字
	ContractName string
	// Cache | Storage
	Cache Cache
	// Event []ss
	/*
		ResourceLimits
		type Limits struct {
			Cpu    int64
			Memory int64
			Disk   int64
			XFee   int64
		}
	*/
	Args   []string
	Method string
	// Instance Instance
	Output [][]byte // 用于对外传递数据，合约可以通过接口设置Output用于合约执行完成之后将指定数据交给节点处理
	Type   string

	// 不同区块链每笔交易可能有各自的不同的上下文处理对象，这里将他作为interface处理
	SpecCtx interface{}

	GasCal
}

type GasCal struct {
	GasLimit int64 `json:"-"` // Gas限制同时也作为gas计算功能开关，当gaslimit为0时表示不开启gas，默认不开启
	GasUsed  int64 `json:"-"` // 当Gas开启时，记录当前交易Gas开销
}
